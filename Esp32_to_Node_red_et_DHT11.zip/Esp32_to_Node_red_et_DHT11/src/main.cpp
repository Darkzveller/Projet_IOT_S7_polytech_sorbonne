#include <Arduino.h>
#include "WiFi.h"
#include <HTTPClient.h>

#define MON_TELEPHONE
// #define MA_FREEBOX

const char *name_card_elec = "esp32_test_node_red_v2"; // Nom d'hôte de la carte ESP32
// BESOIN DE ME SIMPLIFIER MA VIE
#ifdef MON_TELEPHONE
const char *ssid = "Me voici";      // SSID du réseau WiFi
const char *password = "youssef13"; // Mot de passe du réseau WiFi
String serverName = "http://192.168.238.171:1880/compteur";
#endif
#ifdef MA_FREEBOX                                // Nom d'hôte de la carte ESP32
const char *ssid = "Freebox-10E503";             // SSID du réseau WiFi
const char *password = "h2nn5qzkvfq639rfqv5s2v"; // Mot de passe du réseau WiFi
String serverName = "http://192.168.1.110:1880/compteur";
#endif

int DHpin = 4;
byte dat[5];
byte read_data()
{

  byte data = 0;
  for (int i = 0; i < 8; i++)
  {
    if (digitalRead(DHpin) == LOW)
    {
      while (digitalRead(DHpin) == LOW)
        ;
      delayMicroseconds(30);
      if (digitalRead(DHpin) == HIGH)
        data |= (1 << (7 - i));
      while (digitalRead(DHpin) == HIGH)
        ;
    }
  }
  return data;
}
void start_test()
{
  digitalWrite(DHpin, LOW);
  delay(30);
  digitalWrite(DHpin, HIGH);
  delayMicroseconds(40);
  pinMode(DHpin, INPUT);
  while (digitalRead(DHpin) == HIGH)
    ;
  delayMicroseconds(80);
  if (digitalRead(DHpin) == LOW)
    ;
  delayMicroseconds(80);
  for (int i = 0; i < 4; i++)
    dat[i] = read_data();
  pinMode(DHpin, OUTPUT);
  digitalWrite(DHpin, HIGH);
}
void setup()
{
  Serial.begin(9600);
  pinMode(DHpin, OUTPUT);

  // Définit le nom d'hôte pour la carte ESP32 sur le réseau
  WiFi.setHostname(name_card_elec);
  // Passe le WiFi en mode station (client du réseau WiFi)
  WiFi.mode(WIFI_STA);

  // Démarre la connexion WiFi avec les identifiants donnés
  WiFi.begin(ssid, password);
  Serial.println();
  Serial.print("SSID : ");
  Serial.println(ssid);

  Serial.println("Connexion au WiFi en cours...");

  // Boucle jusqu'à ce que la connexion au WiFi soit réussie
  while (WiFi.waitForConnectResult() != WL_CONNECTED)
  {
    Serial.println("Connection Failed! Rebooting...");
    delay(1000);
    // Redémarrage si la connexion échoue (commenté pour l'instant)
    ESP.restart();
  }

  Serial.print("Adresse IP ESP32 : ");
  Serial.println(WiFi.localIP());

  // Affiche le succès de la connexion
  Serial.println("");
  Serial.println("Connexion établie !");
}

void loop()
{
  start_test();
  Serial.print("Current humdity =");
  Serial.print(dat[0], DEC);
  Serial.print('.');
  Serial.print(dat[1], DEC);
  Serial.println('%');
  Serial.print("Current temperature =");
  Serial.print(dat[2], DEC);
  Serial.print('.');
  Serial.print(dat[3], DEC);
  Serial.println('C');
  delay(1000);

  static int compteur = 0;
  delay(1000);
  compteur++;

  if (WiFi.status() == WL_CONNECTED)
  {
    HTTPClient http;

    http.begin(serverName.c_str());

    // Indique au serveur le type de données envoyées
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    // Données envoyées dans le corps (body) de la requête POST
    String httpRequestData = "compteur=" + String(compteur);

    // Exécution de la requête POST
    int httpResponseCode = http.POST(httpRequestData);

    if (httpResponseCode > 0)
    {
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
      String payload = http.getString();
      Serial.println(payload);
    }
    else
    {
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
    }

    http.end();
  }
  else
  {
    Serial.println("Wi-Fi déconnecté");
  }
  delay(1000);
}